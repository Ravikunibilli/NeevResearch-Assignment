import React, {useState} from 'react'
import Webcam from 'react-webcam'
import axios from 'axios'

function App() {
  const [scannedData, setScannedData] = useState('')
  const [formData, setFormData] = useState({
    name: '',
    dob: '',
    address: '',
    contact: '',
    gender: '',
  })

  const webcamRef = React.useRef(null)

  const handleBarcodeScan = () => {
    const imageSrc = webcamRef.current.getScreenshot()

    // Send the image to your backend for barcode scanning.
    axios
      .post('/api/scan-barcode', {image: imageSrc})
      .then(response => {
        setScannedData(response.data)
      })
      .catch(error => {
        console.error('Barcode scanning failed', error)
      })
  }

  const handleFormSubmit = () => {
    // Send the form data to your backend for storage.
    axios.post('/api/store-candidate', formData).catch(error => {
      console.error('Candidate data storage failed', error)
    })
  }

  return (
    <div>
      <h1>Barcode Scanner and Candidate Data Storage</h1>
      <Webcam audio={false} ref={webcamRef} screenshotFormat="image/jpeg" />

      <button type="button" onClick={handleBarcodeScan}>
        Scan Barcode
      </button>
      {scannedData && (
        <div>
          <p>Scanned Data: {scannedData}</p>
          <input
            type="text"
            placeholder="Name"
            value={formData.name}
            onChange={e => setFormData({...formData, name: e.target.value})}
          />
          {/* Repeat for other form fields */}
          <button type="button" onClick={handleFormSubmit}>
            Submit Candidate Data
          </button>
        </div>
      )}
    </div>
  )
}

export default App
