const express = require('express')
const bodyParser = require('body-parser')
const app = express()

app.use(bodyParser.json())

// SQLite database setup
const sqlite3 = require('sqlite3').verbose()
const db = new sqlite3.Database('candidates.db')

// Create a candidates table if it doesn't exist
db.serialize(() => {
  db.run(
    'CREATE TABLE IF NOT EXISTS candidates (id INTEGER PRIMARY KEY, name TEXT, dob TEXT, address TEXT, contact TEXT, gender TEXT)',
  )
})

// API endpoint to scan a barcode
app.post('/api/scan-barcode', (req, res) => {
  // Implement barcode scanning logic here (using quaggaJS or a suitable library).
  // Simulate scanning for this example by echoing the image data.
  const imageData = req.body.image
  res.send(`Scanned: ${imageData}`)
})

// API endpoint to store candidate data
app.post('/api/store-candidate', (req, res) => {
  const {name, dob, address, contact, gender} = req.body
  const stmt = db.prepare(
    'INSERT INTO candidates (name, dob, address, contact, gender) VALUES (?, ?, ?, ?, ?)',
  )
  stmt.run(name, dob, address, contact, gender)
  stmt.finalize()
  res.status(201).send('Candidate data stored successfully')
})

const PORT = process.env.PORT || 5000
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`)
})
